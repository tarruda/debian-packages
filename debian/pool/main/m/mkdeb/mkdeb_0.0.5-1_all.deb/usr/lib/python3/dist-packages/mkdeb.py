#!/usr/bin/env python3

# required packages
# - devscripts
# - dget
# - dh-make
# - lsb_release
# - python-stdeb
# - python3-stdeb
# - reprepro
# - wget
import argparse
import configparser
import glob 
import hashlib 
import io
import os
import re
import shutil
import sys
import functools


import ush


(
    apt, awk, debchange, debuild, dget, dh_make, dpkg_source, find, git, gpg,
    mkdir, mv, py2dsc, pypi_download, reprepro, rm, sh, sha256sum, touch, wget
) = ush.Shell(raise_on_error=True)(
    'apt', 'awk', 'debchange', 'debuild', 'dget', 'dh_make', 'dpkg-source',
    'find', 'git', 'gpg', 'mkdir', 'mv', 'py2dsc', 'pypi-download', 'reprepro',
    'rm', 'sh', 'sha256sum', 'touch', 'wget'
)


def parse_args():
    parser = argparse.ArgumentParser(
        description='Automates creation of debian source packages')
    parser.add_argument(
        '-C', '--directory', required=False, default='.',
        help='Change to directory before starting')
    parser.add_argument(
        '--packages', required=False, default='*',
        help='Specify which packages to process')
    parser.add_argument(
        '-b', '--build', required=False, default=False, action='store_true',
        help='Build the package after preparing the source tree')
    parser.add_argument(
        '-r', '--repository', required=False, default=None,
        help='Update a debian repository with reprepro')
    parser.add_argument(
        '-o', '--sources-directory', required=False, default='build',
        help='Sources directory used to store built source packages')
    return parser.parse_args()


def sha256check(path, value):
    (io.StringIO('{} {}'.format(value.strip(), path)) | sha256sum('-c', '-'))()


def create_with_existing_dsc(config, directory, work_dir):
    dsc_url = config['url']
    dsc_sha256 = config['sha256']
    dget('--download-only', dsc_url, cwd=work_dir)()
    dsc_file = glob.glob('{}/*.dsc'.format(work_dir))[0]
    sha256check(dsc_file, dsc_sha256)
    match = re.match(r'([a-z0-9+-.]+)_([0-9][0-9A-Za-z+~.]+)[^.]+\.dsc',
                     os.path.basename(dsc_file))
    if not match:
        raise Exception('Cannot parse dsc filename')
    pkg_name = match.group(1)
    upstream_version = match.group(2)
    src_dir = '{}/{}-{}'.format(work_dir, pkg_name, upstream_version)
    rm('-rf', src_dir)()
    dpkg_source('-x', dsc_file, cwd=work_dir)()
    if not os.path.isdir(src_dir):
        raise Exception('Unexpected directory name')
    # remove the original .dsc file since we'll create a new one
    rm('-v', dsc_file)()
    src_dir = os.path.realpath(src_dir)
    patch_command = config.get('patch-command', None)
    if patch_command:
        patch_command = patch_command.format(config_dir=directory)
        sh('-c', patch_command, cwd=src_dir)()
    changes = config['changelog'].strip().split('\n')
    debchange('--package', pkg_name, '--increment', changes[0], cwd=src_dir)() 
    for change in changes[1:]:
        debchange(change, cwd=src_dir)() 
    reprepro_deb_pattern = config.get('reprepro-include-pattern', None)
    if reprepro_deb_pattern:
        with open('{}/.reprepro-include-pattern'.format(work_dir), 'w') as f:
            f.write(reprepro_deb_pattern)
    return src_dir


def create_with_dh_make(config, directory, work_dir):
    pkg_class = {
        'single': 's',
        'indep': 'i',
        'library': 'l',
    }[config.get('package-type', 'indep')]
    pkg_name = config['package']
    pkg_vers = config['version']
    pkg_template = config.get('template',
                              '').format(config_dir=directory).strip()
    src_dir = '{}/{}-{}'.format(work_dir, pkg_name, pkg_vers)
    rm('-rf', src_dir)()
    mkdir('-pv', src_dir)()
    argv = ['-C', pkg_class, '-y', '--native']
    if pkg_template:
        argv += ['--templates', pkg_template]
    dh_make(*argv,  cwd=src_dir)()
    rm('-f', 'debian/changelog', cwd=src_dir)()
    debchange('--create', '--package', pkg_name, '--newversion', pkg_vers,
              'Initial release', cwd=src_dir)() 
    return src_dir


def create_with_stdeb(config, directory, work_dir, release):
    url = config['url']
    sha256 = config['sha256']
    wget(url, cwd=work_dir)()
    tarball = glob.glob('{}/*'.format(work_dir))[0]
    sha256check(tarball, sha256)
    argv = ['--suite', release, '--dist-dir', '.',]
    python_version = config.get('python-version', None)
    if python_version == '3':
        argv.append('--with-python3=True')
        argv.append('--with-python2=False')
    elif python_version == '2':
        argv.append('--with-python3=False')
        argv.append('--with-python2=True')
    else:
        argv.append('--with-python3=True')
        argv.append('--with-python2=True')
    extra_cfg = '{}/stdeb.cfg'.format(directory)
    if os.path.exists(extra_cfg):
        argv += ['--extra-cfg-file', extra_cfg]
    argv.append(tarball)
    py2dsc(*argv, cwd=work_dir)()
    return glob.glob('{}/*/'.format(work_dir))[0]


def set_name_and_email(args):
    try:
        if not os.environ.get('DEBFULLNAME', None):
            name = list(git('config', '--global', 'user.name'))[0]
            os.environ['DEBFULLNAME'] = name
        if not os.environ.get('DEBEMAIL', None):
            email = list(git('config', '--global', 'user.email'))[0]
            os.environ['DEBEMAIL'] = email
    except OSError:
        pass


def get_current_release():
    return list(sh('-c', 'lsb_release -c') | awk('{print $2}'))[0]


def build_source_package(directory, release, sources_directory, reprepro_files):
    config = configparser.ConfigParser()
    config.read('{}/mkdeb.cfg'.format(directory))
    config = config['main']
    work_dir = '{}/{}'.format(sources_directory, os.path.basename(directory))
    rm('-rf', work_dir)()
    mkdir('-pv', work_dir)()
    generator = config['generator']
    if generator == 'dsc':
        src_dir = create_with_existing_dsc(config, directory, work_dir)
    elif generator == 'dh-make':
        src_dir = create_with_dh_make(config, directory, work_dir)
    elif generator == 'stdeb':
        src_dir = create_with_stdeb(config, directory, work_dir, release)
    else:
        assert False
    debchange('--release', '--distribution', release, '--force-distribution',
              '', cwd=src_dir)() 
    argv = ['-i', '-I', '-S']
    if config.get('sign', 'yes') != 'yes':
        argv += ['-us', '-uc']
    else:
        key = config.get('sign-key', None)
        if not key:
            key = discover_signing_key()
        argv += ['-k{}'.format(key)]
    # build the source package
    timestamp = '{}/timestamp'.format(work_dir)
    touch(timestamp)()
    debuild(*argv, cwd=src_dir)()
    # for f in find('.', '-type', 'f', '-name', '*.dsc', '-newer', timestamp,
    #               cwd=work_dir):
    #     reprepro_files.append(os.path.abspath(os.path.join(work_dir, f)))
    rm('-rf', src_dir)()


def build_package(dir, reprepro_files):
    dsc_file = glob.glob('{}/*.dsc'.format(dir))[0]
    dpkg_source('-x', dsc_file, cwd=dir)()
    src_dir = glob.glob('{}/*/'.format(dir))[0]
    timestamp = '{}/timestamp'.format(dir)
    touch(timestamp)()
    debuild('-i', '-I', '-b', env={'DEB_BUILD_OPTIONS': 'nocheck'},
            cwd=src_dir)()
    include_pattern = r'^.*$'
    if os.path.exists('{}/.reprepro-include-pattern'.format(dir)):
        with open('{}/.reprepro-include-pattern'.format(dir)) as f:
            include_pattern = f.read()
    include_pattern = re.compile(include_pattern)
    for f in find('.', '-type', 'f', '(', '-name', '*.deb', '-o', '-name',
                  '*.udeb', ')', '-newer', timestamp, cwd=dir):
        if include_pattern.search(os.path.basename(f)):
            reprepro_files.append(os.path.abspath(os.path.join(dir, f)))
    rm('-rf', src_dir)()


def build_packages(sources_directory, packages, reprepro_files):
    for pkg in packages:
        build_package('{}/{}'.format(sources_directory, pkg), reprepro_files)


@functools.lru_cache(maxsize=None)
def discover_signing_key():
    for l in gpg('--list-secret-keys', '--with-colons'):
        if l.startswith('sec:'):
            return l.split(':')[4]
    raise Exception('Could not find a valid signing key')


def update_repository(directory, repository, reprepro_files, release):
    config_file = '{}/reprepro.cfg'.format(directory)
    if os.path.exists(config_file):
        config = configparser.ConfigParser()
        config.read(config_file)
        config = config['main']
    else:
        config = {}
    reprepro_dir = '{}/reprepro'.format(directory)
    if not os.path.exists('{}/reprepro'):
        mkdir('-pv', '{}/conf'.format(reprepro_dir))()
        mkdir('-pv', '{}/incoming'.format(reprepro_dir))()
        conf_lines = [
            'Origin: {}'.format(config.get('origin', 'mkdeb')),
            'Label: {}'.format(config.get('label', 'mkdeb')),
            'Codename: {}'.format(release),
            'Architectures: {}'.format(config.get('architectures',
                                                  'amd64 armhf source')),
            'Components: {}'.format(config.get('components', 'main')),
            'Description: {}'.format(
                config.get('description',
                           'Repository automatically generated by mkdeb')),
        ]
        if config.get('sign', 'yes') == 'yes':
            key = config.get('sign-key', None)
            if not key:
                key = discover_signing_key()
            conf_lines.append('SignWith: {}'.format(key))
        conf_lines.append('')
        with open('{}/conf/distributions'.format(reprepro_dir), 'w') as c:
            c.write('\n'.join(conf_lines))
        with open('{}/conf/options'.format(reprepro_dir), 'w') as c:
            c.write('\n'.join([
                'outdir {}'.format(repository),
                ''
            ]))
    for f in reprepro_files:
        if f.endswith('.dsc'):
            reprepro('includedsc', release, f, cwd=reprepro_dir)()
        elif f.endswith('.deb'):
            reprepro('includedeb', release, f, cwd=reprepro_dir)()

def main():
    args = parse_args()
    args.directory = os.path.abspath(args.directory)
    args.repository = os.path.abspath(args.repository)
    args.sources_directory = os.path.abspath(args.sources_directory)
    release = '{}-mkdeb'.format(get_current_release())
    set_name_and_email(args)
    reprepro_files = []
    if args.packages == '*':
        packages = []
        for de in os.scandir(args.directory):
            if (de.is_dir() and
                os.path.exists('{}/{}/mkdeb.cfg'.format(args.directory,
                                                        de.name))):
                packages.append(de.name)
    else:
        packages = args.packages.split(',')
    for pkg in packages:
        if os.path.exists('{}/{}/mkdeb.cfg'.format(args.directory, pkg)):
            print('processing {}'.format(pkg))
            build_source_package('{}/{}'.format(args.directory, pkg),
                                 release, args.sources_directory,
                                 reprepro_files)
    if args.build:
        build_packages(args.sources_directory, packages, reprepro_files)
    if args.repository:
        update_repository(args.directory, args.repository, reprepro_files,
                          release)


if __name__ == '__main__':
    sys.exit(main())
