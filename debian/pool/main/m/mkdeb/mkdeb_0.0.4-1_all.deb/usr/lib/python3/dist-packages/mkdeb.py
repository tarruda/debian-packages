#!/usr/bin/env python3

# required packages
# - lsb_release
# - dh-make
# - devscripts
# - reprepro
# - apt-show-source
# - python-stdeb
# - python3-stdeb
import argparse
import configparser
import glob 
import hashlib 
import io
import os
import re
import shutil
import sys
import tempfile


import ush


(
    apt, apt_show_source, awk, debchange, debuild, dh_make, dpkg_source, find,
    git, gpg, mkdir, mv, py2dsc, pypi_download, reprepro, rm, sh, sha256sum,
    sort, touch, xargs
) = ush.Shell(raise_on_error=True)(
    'apt', 'apt-show-source', 'awk', 'debchange', 'debuild', 'dh_make',
    'dpkg-source', 'find', 'git', 'gpg', 'mkdir', 'mv', 'py2dsc',
    'pypi-download', 'reprepro', 'rm', 'sh', 'sha256sum', 'sort', 'touch',
    'xargs'
)


def parse_args():
    parser = argparse.ArgumentParser(
        description='Automates creation of debian source packages')
    parser.add_argument(
        '-C', '--directory', required=False, default='.',
        help='Change to directory before starting')
    parser.add_argument(
        '--batch', required=False, default=False, action='store_true',
        help=('Batch mode processing. Iterate each subdirectory to build '
              'multiple packages.'))
    parser.add_argument(
        '-b', '--build', required=False, default=False, action='store_true',
        help='Build the package after preparing the source tree')
    parser.add_argument(
        '-r', '--repository', required=False, default=None,
        help='Update a debian repository with reprepro')
    parser.add_argument(
        '-o', '--sources-directory', required=False, default='build',
        help='Sources directory used to store built source packages')
    return parser.parse_args()


def create_with_existing_deb_src(config, directory, work_dir):
    apt('source', '--download-only', config['package'], cwd=work_dir)()
    dsc_file = glob.glob('{}/*.dsc'.format(work_dir))[0]
    match = re.match(r'([a-z0-9+-.]+)_([0-9][0-9A-Za-z+~.]+)[^.]+\.dsc',
                     os.path.basename(dsc_file))
    if not match:
        raise Exception('Cannot parse dsc filename')
    pkg_name = match.group(1)
    upstream_version = match.group(2)
    src_dir = '{}/{}-{}'.format(work_dir, pkg_name, upstream_version)
    rm('-rf', src_dir)()
    dpkg_source('-x', dsc_file, cwd=work_dir)()
    if not os.path.isdir(src_dir):
        raise Exception('Unexpected directory name')
    # remove the original .dsc file since we'll create a new one
    rm('-v', dsc_file)()
    src_dir = os.path.realpath(src_dir)
    patch_command = config.get('patch-command', None)
    if patch_command:
        patch_command = patch_command.format(config_dir=directory)
        sh('-c', patch_command, cwd=src_dir)()
    changes = config['changelog'].strip().split('\n')
    debchange('--package', pkg_name, '--increment', changes[0], cwd=src_dir)() 
    for change in changes[1:]:
        debchange(change, cwd=src_dir)() 
    return src_dir


def create_with_dh_make(config, directory, work_dir):
    pkg_class = {
        'single': 's',
        'indep': 'i',
        'library': 'l',
    }[config.get('package-type', 'indep')]
    pkg_name = config['package']
    pkg_vers = config['version']
    pkg_template = config.get('template',
                              '').format(config_dir=directory).strip()
    src_dir = '{}/{}-{}'.format(work_dir, pkg_name, pkg_vers)
    rm('-rf', src_dir)()
    mkdir('-pv', src_dir)()
    argv = ['-C', pkg_class, '-y', '--native']
    if pkg_template:
        argv += ['--templates', pkg_template]
    dh_make(*argv,  cwd=src_dir)()
    rm('-f', 'debian/changelog', cwd=src_dir)()
    debchange('--create', '--package', pkg_name, '--newversion', pkg_vers,
              'Initial release', cwd=src_dir)() 
    return src_dir


def create_with_stdeb(config, directory, work_dir, release):
    pkg_name = config['package']
    pkg_vers = config['version']
    pkg_sha256 = config['sha256']
    pypi_pkg_name = config.get('pypi-package', pkg_name)
    pypi_download(pypi_pkg_name, '--allow-unsafe-download',
                  '--release={}'.format(pkg_vers), cwd=work_dir)()
    (io.StringIO(pkg_sha256.strip()) | sha256sum('-c', '-', cwd=work_dir))()
    argv = ['--suite', release, '--dist-dir', '.',]
    python_version = config.get('python-version', None)
    if python_version == '3':
        argv.append('--with-python3=True')
        argv.append('--with-python2=False')
    elif python_version == '2':
        argv.append('--with-python3=False')
        argv.append('--with-python2=True')
    else:
        argv.append('--with-python3=True')
        argv.append('--with-python2=True')
    extra_cfg = '{}/stdeb.cfg'.format(directory)
    if os.path.exists(extra_cfg):
        argv += ['--extra-cfg-file', extra_cfg]
    argv.append('*')
    py2dsc(*argv, glob=True, cwd=work_dir)()
    src_dir = '{}/{}-{}'.format(work_dir, pkg_name, pkg_vers)
    return src_dir


def set_name_and_email(args):
    try:
        if not os.environ.get('DEBFULLNAME', None):
            name = list(git('config', '--global', 'user.name'))[0]
            os.environ['DEBFULLNAME'] = name
        if not os.environ.get('DEBEMAIL', None):
            email = list(git('config', '--global', 'user.email'))[0]
            os.environ['DEBEMAIL'] = email
    except OSError:
        pass


def get_current_release():
    return list(sh('-c', 'lsb_release -c') | awk('{print $2}'))[0]


def compute_version_sha256(directory, config):
    checksum = hashlib.sha256()
    # include the sha256 of every relevant file
    checksum.update(bytes(
        git('ls-tree', '-r', '--name-only', 'HEAD', cwd=directory) |
        sort('-u') |
        xargs('sha256sum', cwd=directory)
        ))
    if config['generator'] == 'deb-src':
        # include the original package version so we rebuild when a new version
        # is available
        checksum.update(
            bytes(apt_show_source('--package', config['package'],
                                  '--version-only')))
    return checksum.hexdigest()


def check_version(directory, config, work_dir, new_sha256):
    version_file = '{}/.sha256'.format(work_dir)
    if not os.path.exists(version_file):
        return False
    with open(version_file) as f:
        current_sha256 = f.read()
    return current_sha256 == new_sha256


def update_version(directory, config, work_dir, new_sha256):
    version_file = '{}/.sha256'.format(work_dir)
    with open(version_file, 'w') as f:
        f.write(new_sha256)


def build_source_package(directory, release, sources_directory, reprepro_files):
    config = configparser.ConfigParser()
    config.read('{}/mkdeb.cfg'.format(directory))
    config = config['main']
    work_dir = '{}/{}'.format(sources_directory, config['package'])
    mkdir('-pv', work_dir)()
    new_sha256 = compute_version_sha256(directory, config)
    if check_version(directory, config, work_dir, new_sha256):
        print('Package {} is up to date'.format(config['package']))
        reprepro_files += glob.glob('{}/*.dsc'.format(work_dir))
        return
    generator = config['generator']
    if generator == 'deb-src':
        src_dir = create_with_existing_deb_src(config, directory, work_dir)
    elif generator == 'dh-make':
        src_dir = create_with_dh_make(config, directory, work_dir)
    elif generator == 'stdeb':
        src_dir = create_with_stdeb(config, directory, work_dir, release)
    else:
        assert False
    debchange('--release', '--distribution', release, '--force-distribution',
              '', cwd=src_dir)() 
    argv = ['-i', '-I', '-S']
    if config.get('sign', 'yes') != 'yes':
        argv += ['-us', '-uc']
    else:
        key = config.get('sign-key', None)
        if not key:
            key = discover_signing_key()
        conf_lines.append('SignWith: {}'.format(key))
    # build the source package
    timestamp = '{}/timestamp'.format(work_dir)
    touch(timestamp)()
    debuild(*argv, cwd=src_dir)()
    for f in find('.', '-type', 'f', '-newer', timestamp, cwd=work_dir):
        if f.endswith('.dsc'):
            reprepro_files.append(os.path.abspath(os.path.join(work_dir, f)))
    rm('-rf', src_dir)()
    update_version(directory, config, work_dir, new_sha256)


def build_package(dir):
    dsc_file = glob.glob('{}/*.dsc'.format(dir))[0]
    built_dsc_file = '{}/.built-dsc'.format(dir)
    if glob.glob('{}/*.deb'.format(dir)) and os.path.exists(built_dsc_file):
        with open(built_dsc_file) as f:
            built_dsc = f.read().strip()
        with open(dsc_file) as f:
            dsc = f.read().strip()
        if built_dsc == dsc:
            print('No need to build {}'.format(os.path.basename(dsc_file)))
            return
    dpkg_source('-x', dsc_file, cwd=dir)()
    src_dir = glob.glob('{}/*/'.format(dir))[0]
    debuild('-i', '-I', '-b', env={'DEB_BUILD_OPTIONS': 'nocheck'},
            cwd=src_dir)()
    shutil.copy(dsc_file, built_dsc_file)
    rm('-rf', src_dir)()


def build_packages(sources_directory, reprepro_files):
    for de in os.scandir(sources_directory):
        if not de.is_dir():
            continue
        build_package('{}/{}'.format(sources_directory, de.name))


def discover_signing_key():
    for l in gpg('--list-secret-keys', '--with-colons'):
        if l.startswith('sec:'):
            return l.split(':')[4]
    raise Exception('Could not find a valid signing key')


def update_repository(config, repository, reprepro_files, release):
    with tempfile.TemporaryDirectory(prefix='mkdeb-reprepro') as d:
        mkdir('-pv', '{}/conf'.format(d))()
        mkdir('-pv', '{}/incoming'.format(d))()
        conf_lines = [
            'Origin: {}'.format(config.get('origin', 'mkdeb')),
            'Label: {}'.format(config.get('label', 'mkdeb')),
            'Codename: {}'.format(release),
            'Architectures: {}'.format(config.get('architectures',
                                                  'amd64 armhf source')),
            'Components: {}'.format(config.get('components', 'main')),
            'Description: {}'.format(
                config.get('description',
                           'Repository automatically generated by mkdeb')),
        ]
        if config.get('sign', 'yes') == 'yes':
            key = config.get('sign-key', None)
            if not key:
                key = discover_signing_key()
            conf_lines.append('SignWith: {}'.format(key))
        conf_lines.append('')
        with open('{}/conf/distributions'.format(d), 'w') as c:
            c.write('\n'.join(conf_lines))
        for f in reprepro_files:
            if f.endswith('.dsc'):
                reprepro('--outdir', repository, 'includedsc', release, f,
                         cwd=d)()

def main():
    args = parse_args()
    args.directory = os.path.abspath(args.directory)
    args.repository = os.path.abspath(args.repository)
    args.sources_directory = os.path.abspath(args.sources_directory)
    release = '{}-mkdeb'.format(get_current_release())
    set_name_and_email(args)
    reprepro_files = []
    if args.batch:
        for de in os.scandir(args.directory):
            if (de.is_dir() and
                os.path.exists('{}/{}/mkdeb.cfg'.format(args.directory,
                                                        de.name))):
                print('processing {}'.format(de.name))
                build_source_package('{}/{}'.format(args.directory, de.name),
                                     release, args.sources_directory,
                                     reprepro_files)
        if args.build:
            build_packages(args.sources_directory, reprepro_files)
        if args.repository:
            reprepro_cfg_file = '{}/reprepro.cfg'.format(args.directory)
            if os.path.exists(reprepro_cfg_file):
                config = configparser.ConfigParser()
                config.read(reprepro_cfg_file)
                reprepro_cfg = config['main']
            else:
                reprepro_cfg = {}
            update_repository(reprepro_cfg, args.repository, reprepro_files,
                              release)
    else:
        if not os.path.exists('{}/mkdeb.cfg'.format(args.directory)):
            print('No mkdeb.cfg in {}'.format(args.directory), file=sys.stderr)
            return 1
        build_source_package(args.directory, release, args.sources_directory)
        if args.build:
            print('--build is only supported with --batch', file=sys.stderr)
            return 1


if __name__ == '__main__':
    sys.exit(main())
